public interface Tributavel {

    public Double getValorImposto();
}
