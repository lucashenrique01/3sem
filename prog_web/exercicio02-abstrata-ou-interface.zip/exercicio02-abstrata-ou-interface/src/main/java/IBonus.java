public interface IBonus {
    public Double getValorBonus();
}

// Optei por utilizar a interface pois como o caso de uso pede para apenas implentar obrigatoriamente apenas 1 metodo e
// nenhum atributo achei que essa seria a melhor forma, usar uma classe abstrata aqui seria estranho por professor e fun
// funcionario não seria abstraidos de uma classe mãe de forma correta.
